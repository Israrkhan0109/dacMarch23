package in.cdac.Tester;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import in.cdac.domain.Car;
import in.cdac.domain.Driver;
import in.cdac.domain.User;

public class Test {
	List<User> arrList =new ArrayList<>();
		
	public void addUser(User arr) {
		if(arr!=null)
			this.arrList.add (arr);
		/*for (User user : arrList) {
				System.out.println(user);
			}*/
		}
	
	private static Scanner sc = new Scanner(System.in);
	public static User acceptRecord(User user) {
		if(user!=null) {
			System.out.print("Enter Name : ");
			user.setName(sc.nextLine());
			System.out.print("Enter Phone Number :	");
			user.setPhoneNumber(sc.nextLine());
			System.out.print("Enter Email Id :	");
			user.setEmailId(sc.nextLine());
			System.out.print("Set Password : ");
			user.setPassword(sc.nextInt());
			Test test = new Test();
			test.addUser(user);
		
		}
		return user;
	}
	
	public static  Car[] carDetails() {
		 Car[] arr=new Car[5] ;
		 arr[0]=new Car("Toyota Fortuner", "SUV", 7);
		 arr[1]=new Car("Toyota Innova Crysta", "SUV", 7);
		 arr[2]=new Car("Honda City", "Sedan", 5);
		 arr[3]=new Car("Mercedes Benz C200", "Compact Sedan", 5);
		 arr[4]=new Car("Mercedes Benz S650","Luxury Sedan",4);
		 return arr;
	}
	public static  Driver[] driverDetails() {
		 Driver[] arr=new Driver[5] ;
		 arr[0]=new Driver("Raja",34,"4589-6325-4789","6253024150");
		 arr[1]=new Driver("Sanjay",40,"2356-2145-8569","9654782314");
		 arr[2]=new Driver("Vjay",41,"1254-8563-1257","8563214569");
		 arr[3]=new Driver("Rana",44,"4523-7856-9854","7852314569");
		 arr[4]=new Driver("Suresh",46,"1235-4865-8962","7563214852");
		 return arr;
	}
	
	
			
}
