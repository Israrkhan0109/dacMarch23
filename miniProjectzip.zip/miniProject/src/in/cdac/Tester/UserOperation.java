package in.cdac.Tester;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import in.cdac.domain.User;

public class UserOperation {
	private static Scanner sc = new Scanner(System.in);
	public static void userRegistration() throws IOException {
		User person =Test.acceptRecord(new User());
		FileWriter fw = new FileWriter("registered_users.txt", true);
        fw.write(person.getName() + "," + person.getEmailId() + "," + person.getPhoneNumber() + ","+person.getPassword() + "\n");
        fw.close();
        System.out.println("Registration successful!");
      
	}
	public static String userLogin() throws FileNotFoundException {
		System.out.println("Enter your contact number : ");
		//sc.nextLine();
		String contactNo=sc.nextLine();
		System.out.println("Enter your password ");
		String password=sc.nextLine();
		
		Scanner scanner = new Scanner(new File("registered_users.txt"));
        
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            
            String[] parts = line.split(",");
            String storedContactNo = parts[2];
            String storedPassword = parts[3];
            
            if (contactNo.equals(storedContactNo) && password.equals(storedPassword)) {
				
                System.out.println("Login successful!\n ");
                return contactNo;
            }
        }
		return null;
	}
	public static void showRecord(String str) throws FileNotFoundException {
		Scanner scanner = new Scanner(new File("registered_users.txt")); 
		while (scanner.hasNextLine()) {
	            String line = scanner.nextLine();
	            
	            String[] parts = line.split(",");
	            String storedName = parts[0];
	            String storedEmailId = parts[1];
	            String storedContactNo = parts[2];
	            
	            if(str.equals(storedContactNo) ) {
	            	System.out.println("Name : "+storedName+"\nEmail Id : "+storedEmailId+"\nContact Number : "+storedContactNo);
	            }

		}
	}
}
