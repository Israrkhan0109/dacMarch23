package in.cdac.domain;

public class Car {
	//Fields
	private String carName;
	private String carType;
	private int seatingCapacity;
	
	//parameter-less constructor
	public Car() {
		
	}

	//parametrized constructor
	public Car(String carName, String carType, int seatingCapacity) {
		
		this.carName = carName;
		this.carType = carType;
		this.seatingCapacity = seatingCapacity;
	}

	//Getters and Setters
	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	//toString for formatted output
	@Override
	public String toString() {
		return String.format("%-10s%-10s%-10d",this.carName,this.carType,this.seatingCapacity);
	}
	
	
	

}
