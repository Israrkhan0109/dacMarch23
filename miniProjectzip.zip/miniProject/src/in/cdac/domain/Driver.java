package in.cdac.domain;

public class Driver {
	//Fields
	private String name;
	private int age;
	private String licenceNo;
	private String contactNumber;
	
	//parameter-less constructor
		public Driver() {
			
		}
	
	
	//parametrized constructor
	public Driver(String name, int age, String licenceNo, String contactNumber) {
		super();
		this.name = name;
		this.age = age;
		this.licenceNo = licenceNo;
		this.contactNumber = contactNumber;
	}

	//Getters and Setters
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getLicenceNo() {
		return licenceNo;
	}


	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}
	
	
	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
	//toString for formatted output
	@Override
	public String toString() {
		return String.format("%15s%10d%15s",this.name,this.age,this.licenceNo);
	}
	
	
}
