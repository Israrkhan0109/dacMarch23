package in.cdac.main;

import java.io.IOException;
import java.util.Scanner;

import in.cdac.Tester.Test;
import in.cdac.Tester.UserOperation;
import in.cdac.domain.User;

public class Program {
	private static Scanner sc = new Scanner (System.in);
	private static int menuList() {
		System.out.println("1.Sign up");
		System.out.println("2.Sign In");
		System.out.println("3.EXIT");
		return sc.nextInt();
		
	}
	private static int subMenuList() {
		System.out.println("0. Logout.");
		System.out.println("1. View profile.");
		System.out.println("2. Show available rides.");
		System.out.println("3. Book ride.");
		System.out.println("4. Past rides.");
		System.out.println("5. Cancel ride.");
		System.out.println("6. Rate the ride.");
		return sc.nextInt();
	}
	public static void main(String[] args) throws IOException {
		int choice;
		while((choice = Program.menuList())!=3)
		{
			switch(choice) {
			case 1 :
				UserOperation.userRegistration() ;
			case 2 :
				String str = UserOperation.userLogin();
				if(str!=null) {
					while((choice=Program.subMenuList())!=0) {
						switch(choice) {
						case 1:
							UserOperation.showRecord(str);
							break;
						case 2:
							UserOperation.showRide();
							break;
						case 3:
							UserOperation.bookRide(str);
							
							break;
						case 4:
							break;
						case 5:
							break;
						case 6:
							break;
						}
					}
				}
					
				break;
			}
		}
	}
	
}
