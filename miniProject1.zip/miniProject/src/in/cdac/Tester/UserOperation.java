package in.cdac.Tester;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import in.cdac.domain.Car;
import in.cdac.domain.Ride;
import in.cdac.domain.User;

public class UserOperation {
	private static Scanner sc = new Scanner(System.in);
	public static void userRegistration() throws IOException {
		User person =Test.acceptRecord(new User());
		FileWriter fw = new FileWriter("registered_users.txt", true);
        fw.write(person.getName() + "," + person.getEmailId() + "," + person.getPhoneNumber() + ","+person.getPassword() + "\n");
        fw.close();
        System.out.println("Registration successful!");
      
	}
	public static String userLogin() throws FileNotFoundException {
		System.out.println("Enter your contact number : ");
		//sc.nextLine();
		String contactNo=sc.nextLine();
		System.out.println("Enter your password ");
		String password=sc.nextLine();
		
		Scanner scanner = new Scanner(new File("registered_users.txt"));
        
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            
            String[] parts = line.split(",");
            String storedContactNo = parts[2];
            String storedPassword = parts[3];
            
            if (contactNo.equals(storedContactNo) && password.equals(storedPassword)) {
				
                System.out.println("Login successful!\n ");
                return contactNo;
            }
        }
		return null;
	}
	public static void showRecord(String str) throws FileNotFoundException {
		Scanner scanner = new Scanner(new File("registered_users.txt")); 
		while (scanner.hasNextLine()) {
	            String line = scanner.nextLine();
	            
	            String[] parts = line.split(",");
	            String storedName = parts[0];
	            String storedEmailId = parts[1];
	            String storedContactNo = parts[2];
	            
	            if(str.equals(storedContactNo) ) {
	            	System.out.println("Name : "+storedName+"\nEmail Id : "+storedEmailId+"\nContact Number : "+storedContactNo);
	            }

		}
	}
	
	public static Ride showRide() {
		 Ride []ride=Test.rideOptions();
		for(int index = 0;index<ride.length;index++) {
			System.out.println((index+1)+" "+ride[index]);
		}
		return null;
	}
	
	public static Car showCar() {
		Car[] cars=Test.carDetails();
		for(int index = 0;index<cars.length;index++) {
			System.out.println((index+1)+" "+cars[index]);
			
		}
		return null;
	}
	
	public static void bookRide(String str) {
		Ride []ride=Test.rideOptions();
		for(int index = 0;index<ride.length;index++) {
			System.out.println((index+1)+" "+ride[index]);
		}
		System.out.print("Enter your ride option : ");
		int option=sc.nextInt();
		Ride selectedRide=ride[option-1];
		Car[] cars=Test.carDetails();
		for(int index = 0;index<cars.length;index++) {
			System.out.println((index+1)+" "+cars[index]);
			
		}
		System.out.println("Enter your car choice : ");
		int choice =sc.nextInt();
		Car selectedCar=cars[choice-1];
		
		//gst=( distance * car rate )*0.18
		//ttoatl= ( distance * car rate )+gst+50000;
		
		double gst= ( selectedRide.getDistance() * selectedCar.getRate())*0.18;
		double total= ( selectedRide.getDistance() * selectedCar.getRate()) +gst+50000;
		
		System.out.println("Would you like to confirm this ride? (y/n) ");
		if(sc.next().equalsIgnoreCase("y")) {
						
			Scanner scanner = new Scanner(new File("registered_users.txt"));
	        
	        while (scanner.hasNextLine()) {
	            String line = scanner.nextLine();
	            
	            String[] parts = line.split(",");
	            String storedContactNo = parts[2];
	           // String 
	            //car name ride destination total 
	            if (str.equals(storedContactNo)) {
	            	FileWriter fw = new FileWriter("Booking_Details.txt", true);
	    	       // fw.write();
	    	        fw.close();
	    	        System.out.println("Registration successful!");
	            }
					
			
			
			
			
		}
		
		
		
		}
		
		
		
	}
}
	


